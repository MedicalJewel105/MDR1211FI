./objects/mdr32fxqi_rst_clk.o: \
  C:\Users\VitPC\AppData\Local\Arm\Packs\Milandr\MDR32FxQI\1.3.2\Libraries\SPL\MDR32FxQI\src\MDR32FxQI_rst_clk.c \
  C:\Users\VitPC\AppData\Local\Arm\Packs\Milandr\MDR32FxQI\1.3.2\Libraries\SPL\MDR32FxQI\inc\MDR32FxQI_rst_clk.h \
  RTE\Device\MDR32F9Q2I\MDR32FxQI_config.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  RTE\_Target_1\RTE_Components.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\Milandr\MDR32FxQI\1.3.2\Libraries\CMSIS\MDR32FxQI\DeviceSupport\MDR32F9Q2I\inc\MDR32F9Q2I.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\core_cm3.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_version.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_compiler.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\cmsis_armclang.h \
  C:\Users\VitPC\AppData\Local\Arm\Packs\ARM\CMSIS\5.8.0\CMSIS\Core\Include\mpu_armv7.h \
  RTE\Device\MDR32F9Q2I\system_MDR32F9Q2I.h
